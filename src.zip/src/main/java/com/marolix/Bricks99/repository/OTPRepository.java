package com.marolix.Bricks99.repository;

import org.springframework.data.repository.CrudRepository;

import com.marolix.Bricks99.entity.OTPDetails;

public interface OTPRepository extends CrudRepository<OTPDetails, String> {

}
